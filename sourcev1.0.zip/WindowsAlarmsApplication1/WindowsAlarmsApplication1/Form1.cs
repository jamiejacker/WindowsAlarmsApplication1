﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsAlarmsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timer1.Interval == 1200000)
            {
                timer1.Interval = 900000;
                this.TopMost = true;
                MessageBox.Show("wait a second!"+Environment.NewLine+"its break time!","dont you dare going!",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            else
            {
                timer1.Interval = 1200000;
                SystemSounds.Beep.Play();
                MessageBox.Show("ready!","your break is done!",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }
    }
}
